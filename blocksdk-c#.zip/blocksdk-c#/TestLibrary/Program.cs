﻿using System;
using System.Threading.Tasks;

namespace TestLibrary
{
    class Program { 
        static async Task Main(string[] args)
        {
            
            // var bas = new Base("aaa");
            // bas.request("GET", "", new String[] { "" });


			blockSDK = new BlockSDK("ad38QFTevz8fEEAG4fKsf4T5L8pwqgcy6LXMHpqU");

			

			ltcClient = blockSDK.createLitecoin("ad38QFTevz8fEEAG4fKsf4T5L8pwqgcy6LXMHpqU")
			output = ltcClient.getBlockChain("ad38QFTevz8fEEAG4fKsf4T5L8pwqgcy6LXMHpqU")

			print(output)



        }
    }
}
