﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlockSdk
{
    public class Price : Base
    {
        public Price(string api_token) : base(api_token)
        {
        }

    }
}
